<?php
if (!defined('ABSPATH')) exit;

final class Orthocal_Plugin {
    const CALENDAR = 'https://kalender.georg-kloster.ru/api/v1/calendar/';
    const BIBLE = 'https://bible-desktop.com/api/';
    const TITLES = ['today'=>'Сегодня', 'upcoming'=>'Ближайшие праздники', 'month'=>'Календарь на месяц', 'year'=>'Календарь на год', 'day'=>'День календаря', 'readings'=>'Чтения дня'];
    private static $file;
    private static $memo = [];

    static function boot($file) {
        self::$file = $file;
        add_action('init', [self::class, 'register']);
        add_action('wp_enqueue_scripts', function () {
            $post=get_post();
            if ($post && (str_contains($post->post_content,'[orthocal_') || str_contains($post->post_content,'wp:orthocal/'))) {
                wp_enqueue_style('orthocal'); wp_enqueue_script('orthocal');
            }
        });
        add_action('template_redirect', function () {
            $post=get_post();
            if ($post && (str_contains($post->post_content,'[orthocal_') || str_contains($post->post_content,'wp:orthocal/'))) {
                if (!defined('DONOTCACHEPAGE')) define('DONOTCACHEPAGE',true);
                nocache_headers();
            }
        });
        add_action('wp_footer', function () {
            // Shortcodes in widgets/templates may be discovered after wp_head.
            if (wp_style_is('orthocal','enqueued') && !wp_style_is('orthocal','done')) wp_print_styles('orthocal');
        },5);
        add_action('admin_menu', function () { add_options_page('Православный календарь', 'Православный календарь', 'manage_options', 'orthocal', [self::class, 'settings_page']); });
        add_action('admin_enqueue_scripts', function ($hook) {
            if ($hook==='settings_page_orthocal') { wp_enqueue_style('orthocal'); wp_enqueue_script('orthocal'); }
        });
        add_action('admin_init', function () { register_setting('orthocal', 'orthocal_options', ['sanitize_callback'=>[self::class,'sanitize_options']]); });
        add_action('rest_api_init', function () {
            register_rest_route('orthocal/v1', '/render', ['methods'=>'GET', 'permission_callback'=>'__return_true', 'callback'=>[self::class,'rest_render']]);
            register_rest_route('orthocal/v1', '/bible', ['methods'=>'GET', 'permission_callback'=>'__return_true', 'callback'=>[self::class,'rest_bible']]);
        });
    }

    static function options() {
        return wp_parse_args(get_option('orthocal_options', []), ['key'=>'','lang'=>'ru','profile'=>'typikon-strict','theme'=>'book','accent'=>'#9a352d','translation'=>'','oldstyle'=>'1','compact'=>'0']);
    }
    static function sanitize_options($input) {
        $old = self::options(); $out = [];
        foreach (['lang'=>['ru','cu','de','uk','pl'], 'profile'=>['typikon-strict','parish'], 'theme'=>['book','modern','inherit']] as $name=>$allowed) {
            $out[$name] = in_array($input[$name] ?? '', $allowed, true) ? $input[$name] : $old[$name];
        }
        $out['key'] = !empty($input['clear_key']) ? '' : (empty($input['key']) ? $old['key'] : sanitize_text_field($input['key']));
        $out['translation'] = sanitize_text_field($input['translation'] ?? '');
        $out['accent'] = sanitize_hex_color($input['accent'] ?? '') ?: '#9a352d';
        foreach (['oldstyle','compact'] as $name) $out[$name] = empty($input[$name]) ? '0' : '1';
        // Invalidate the previous generation without scanning or deleting unrelated options.
        update_option('orthocal_cache_generation', wp_generate_uuid4(), false);
        return $out;
    }
    static function register() {
        $url = plugin_dir_url(self::$file);
        wp_register_style('orthocal', $url.'assets/calendar.css', [], '1.0.0');
        wp_register_script('orthocal', $url.'assets/calendar.js', [], '1.0.0', true);
        wp_register_script('orthocal-editor', $url.'assets/editor.js', ['wp-blocks','wp-element','wp-block-editor','wp-components','wp-server-side-render'], '1.0.0', true);
        foreach (self::TITLES as $mode=>$title) {
            add_shortcode('orthocal_'.$mode, function ($attrs) use ($mode) { return self::render(is_array($attrs) ? array_merge($attrs, ['mode'=>$mode]) : ['mode'=>$mode]); });
            register_block_type(dirname(self::$file).'/blocks/'.$mode, ['render_callback'=>function ($attrs) use ($mode) { return self::render(array_merge($attrs,['mode'=>$mode])); }]);
        }
    }
    static function key() { return defined('ORTHOCAL_API_KEY') ? ORTHOCAL_API_KEY : self::options()['key']; }
    static function date_valid($date) {
        return is_string($date) && preg_match('/^(19\d{2}|20\d{2}|21\d{2}|2200)-(\d{2})-(\d{2})$/D', $date, $m) && checkdate((int)$m[2], (int)$m[3], (int)$m[1]);
    }
    static function config($attrs) {
        $o = self::options();
        $attrs = array_filter($attrs, static fn($value) => $value !== '');
        $a = shortcode_atts(['mode'=>'today','date'=>'','year'=>'','month'=>'','limit'=>'5','filter'=>'main','lang'=>$o['lang'],'profile'=>$o['profile'],'theme'=>$o['theme'],'compact'=>$o['compact'],'oldstyle'=>$o['oldstyle']], $attrs);
        if (!isset(self::TITLES[$a['mode']])) return new WP_Error('mode','Неизвестный блок.');
        $date = $a['date'] ?: wp_date('Y-m-d');
        if (!self::date_valid($date)) return new WP_Error('date','Дата должна быть в диапазоне 1900–2200, в формате ГГГГ-ММ-ДД.');
        $a['date'] = $date;
        $a['year'] = $a['year'] === '' ? (int)substr($date,0,4) : filter_var($a['year'], FILTER_VALIDATE_INT);
        $a['month'] = $a['month'] === '' ? (int)substr($date,5,2) : filter_var($a['month'], FILTER_VALIDATE_INT);
        $a['limit'] = filter_var($a['limit'], FILTER_VALIDATE_INT);
        if ($a['year'] < 1900 || $a['year'] > 2200 || $a['month'] < 1 || $a['month'] > 12 || $a['limit'] < 1 || $a['limit'] > 10) return new WP_Error('range','Неверный год, месяц или количество праздников.');
        foreach (['lang'=>['ru','cu','de','uk','pl'],'profile'=>['typikon-strict','parish'],'theme'=>['book','modern','inherit'],'filter'=>['main','twelve','great','memorial','all']] as $name=>$allowed) if (!in_array($a[$name],$allowed,true)) return new WP_Error('option','Неверный параметр календаря.');
        foreach (['compact','oldstyle'] as $name) $a[$name] = in_array((string)$a[$name], ['1','true'],true) ? '1' : '0';
        return $a;
    }
    static function request($service, $path, $query = []) {
        $url = ($service === 'calendar' ? self::CALENDAR : self::BIBLE).$path;
        if ($query) $url = add_query_arg($query,$url);
        $cache = 'oc_'.md5($url.'|'.self::key().'|'.get_option('orthocal_cache_generation','0'));
        if (isset(self::$memo[$cache])) return self::$memo[$cache];
        $cached = get_transient($cache);
        if (is_array($cached)) return self::$memo[$cache] = $cached;
        $cooldown = get_transient('oc_cooldown_'.$service);
        if ($cooldown) return new WP_Error('busy','Сервис временно недоступен. Повторите позже.');
        $headers = ['Accept'=>'application/json'];
        if ($service === 'calendar' && self::key()) $headers['X-API-Key'] = self::key();
        $response = wp_safe_remote_get($url, ['timeout'=>25,'redirection'=>0,'headers'=>$headers,'limit_response_size'=>12*1024*1024]);
        if (is_wp_error($response)) return new WP_Error('connection','Не удалось подключиться к '.($service === 'calendar' ? 'календарю.' : 'BibleDesktop.'));
        $status = wp_remote_retrieve_response_code($response);
        if ($status !== 200) {
            if (in_array($status,[429,503],true)) set_transient('oc_cooldown_'.$service,1,min(3600,max(2,(int)wp_remote_retrieve_header($response,'retry-after'))));
            $messages = [401=>'API-ключ отсутствует или недействителен.',403=>'Доступ к API отключён или истёк.',429=>'Достигнут лимит запросов. Повторите позже.',503=>'API занят или обновляется. Повторите позже.'];
            return new WP_Error('upstream',$messages[$status] ?? 'Источник данных недоступен (HTTP '.$status.').');
        }
        $data = json_decode(wp_remote_retrieve_body($response), true);
        if (!is_array($data)) return new WP_Error('schema','Источник вернул неверный формат данных.');
        if ($service === 'calendar') {
            $remaining = wp_remote_retrieve_header($response,'x-api-month-remaining');
            if ($remaining !== '') update_option('orthocal_quota', ['remaining'=>(int)$remaining,'checked'=>time()], false);
        }
        // Calendar grants application caching explicitly. Bible content stays request-local.
        $ttl = $service === 'calendar' ? min(300,max(0,(int)wp_remote_retrieve_header($response,'x-calendar-application-cache-ttl'))) : 0;
        if ($ttl) set_transient($cache,$data,$ttl);
        return self::$memo[$cache] = $data;
    }
    static function data($a) {
        $q = ['lang'=>$a['lang'],'profile'=>$a['profile']]; $mode = $a['mode'];
        if (in_array($mode,['today','day','readings'],true)) {
            if (!self::key() && $mode === 'today') {
                $value = self::request('calendar','today',$q);
                if (!is_wp_error($value) && ($value['day']['date'] ?? '') !== $a['date']) return new WP_Error('timezone','Для даты в часовом поясе этого сайта нужен API-ключ. Публичный день определяется по Europe/Berlin.');
                return $value;
            }
            return self::request('calendar','day',$q+['date'=>$a['date']]);
        }
        if ($mode === 'upcoming') return self::request('calendar','upcoming',$q+['date'=>$a['date'],'limit'=>$a['limit'],'filter'=>$a['filter']]);
        $q += ['year'=>$a['year'],'view'=>'summary'];
        if ($mode === 'month') $q['month'] = $a['month'];
        return self::request('calendar',$mode,$q);
    }
    static function error_html($message) { return '<p class="oc-message" role="status">'.esc_html($message).'</p>'; }
    static function render($attrs, $ajax = false) {
        $a = self::config($attrs);
        if (is_wp_error($a)) return self::error_html($a->get_error_message());
        $selected = false;
        if (!$ajax && !empty($_GET['orthocal_date']) && is_string($_GET['orthocal_date']) && self::date_valid($_GET['orthocal_date'])) {
            $selected = true;
            $a['date'] = $_GET['orthocal_date']; $a['year'] = (int)substr($a['date'],0,4); $a['month'] = (int)substr($a['date'],5,2);
            if (in_array($a['mode'],['today','day'],true)) $a['mode'] = 'day';
        }
        wp_enqueue_style('orthocal'); wp_enqueue_script('orthocal');
        $data = self::data($a);
        $config = $a + ['endpoint'=>rest_url('orthocal/v1/'), 'translation'=>self::options()['translation'], 'liveDate'=>empty($attrs['date']) && empty($_GET['orthocal_date'])];
        $html = '<section class="orthocal oc-theme-'.esc_attr($a['theme']).($a['compact']==='1'?' oc-compact':'').'" style="--oc-accent:'.esc_attr(self::options()['accent']).'" data-oc-language="'.esc_attr($a['lang']).'" data-orthocal="'.esc_attr(wp_json_encode($config)).'" aria-label="'.esc_attr(self::TITLES[$a['mode']]).'">';
        $html .= '<div class="oc-heading"><span class="oc-eyebrow">КАЛЕНДАРНАЯ МАСТЕРСКАЯ</span><h2>'.esc_html(self::TITLES[$a['mode']]).'</h2></div>';
        if (is_wp_error($data)) $html .= self::error_html($data->get_error_message()).'<button type="button" data-oc-retry>Повторить</button>';
        elseif (isset($data['day']['events']) && is_array($data['day']['events'])) $html .= self::day($data['day'],$a);
        elseif ($a['mode']==='upcoming' && isset($data['items'])) {
            $html .= '<div class="oc-upcoming">';
            foreach ($data['items'] as $item) {
                $days = (int)(new DateTimeImmutable($a['date']))->diff(new DateTimeImmutable($item['date']))->format('%a');
                $html .= '<article><span class="oc-eyebrow">'.esc_html(self::date_label($item['date'])).' · '.($days ? 'через '.$days.' дн.' : 'сегодня').'</span>'.self::day_link($item['date'],$item['event']['title']).'</article>';
            }
            $html .= empty($data['items']) ? '<p>В указанном диапазоне событий нет.</p>' : '';
            $html .= '</div><div class="oc-detail">'.($selected ? self::render(array_merge($a,['mode'=>'day']),true) : '').'</div>';
        } elseif (isset($data['days']) && is_array($data['days'])) {
            $html .= self::navigation($a);
            if ($a['mode']==='year') {
                $html .= '<p class="oc-pascha">Пасха · '.esc_html(self::date_label($data['pascha'])).'</p><div class="oc-year">';
                for ($m=1;$m<=12;$m++) $html .= self::month(array_values(array_filter($data['days'],static fn($day)=>(int)substr($day['date'],5,2)===$m)), $a, $m);
                $html .= '</div>';
                if (!empty($data['fastingPeriods'])) $html .= '<details><summary>Постные периоды</summary><ul>'.self::periods($data['fastingPeriods']).'</ul></details>';
            } else $html .= self::month($data['days'],$a,$a['month']);
            $html .= '<p class="oc-legend">✦ Праздник · Красным — воскресенья и великие праздники. Правило поста указано в описании каждой даты.</p><div class="oc-detail">'.($selected ? self::render(array_merge($a,['mode'=>'day']),true) : '').'</div>';
        } else $html .= self::error_html('API требует обновления: ожидаемые поля отсутствуют.');
        return $html.'<p class="oc-status" role="status" aria-live="polite"></p></section>';
    }
    static function date_label($date) {
        $months=['января','февраля','марта','апреля','мая','июня','июля','августа','сентября','октября','ноября','декабря'];
        return (int)substr($date,8,2).' '.$months[(int)substr($date,5,2)-1].' '.substr($date,0,4);
    }
    static function day_link($date,$label) {
        return '<a href="'.esc_url(add_query_arg('orthocal_date',$date)).'" data-oc-date="'.esc_attr($date).'">'.esc_html($label).'</a>';
    }
    static function navigation($a) {
        $year = $a['mode']==='year'; $date = new DateTimeImmutable(sprintf('%04d-%02d-01',$a['year'],$a['month']));
        $html = '<nav class="oc-nav" aria-label="Выбор периода">';
        foreach ([-1,1] as $step) {
            $target = $date->modify(($step<0?'-1':'+1').($year?' year':' month'));
            $disabled = (int)$target->format('Y')<1900 || (int)$target->format('Y')>2200;
            $html .= '<button type="button" data-oc-period="'.$target->format('Y-m-d').'" '.($disabled?'disabled':'').'>'.($step<0?'← Назад':'Вперёд →').'</button>';
        }
        $html .= '<label>Год <input data-oc-year type="number" min="1900" max="2200" value="'.$a['year'].'"></label><button type="button" data-oc-now>Сегодня</button></nav>';
        return $html;
    }
    static function month($days,$a,$month) {
        $months=['Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'];
        $html = '<div class="oc-month"><h3>'.esc_html($months[$month-1].' '.$a['year']).'</h3><div class="oc-grid">';
        foreach (['Пн','Вт','Ср','Чт','Пт','Сб','Вс'] as $name) $html .= '<span class="oc-weekday">'.$name.'</span>';
        if ($days) for ($i=0;$i<(($days[0]['weekday']+6)%7);$i++) $html .= '<span aria-hidden="true"></span>';
        foreach ($days as $day) {
            $events = $day['events'] ?? []; $feasts = array_values(array_filter($events,static fn($e)=>$e['category']==='commemoration' && $e['typeCode']>=0 && $e['typeCode']<=2));
            $red = $day['weekday']===0 || count($feasts)>0; $today = $day['date']===wp_date('Y-m-d');
            $label = self::date_label($day['date']).'. '.($day['foodLabel'] ?? '').'. '.implode('. ',array_column($feasts,'title'));
            $html .= '<a class="oc-cell'.($red?' oc-red':'').($today?' oc-today':'').'" href="'.esc_url(add_query_arg('orthocal_date',$day['date'])).'" data-oc-date="'.esc_attr($day['date']).'" aria-label="'.esc_attr($label).'" title="'.esc_attr($label).'"'.($today?' aria-current="date"':'').'>';
            $html .= '<b>'.(int)substr($day['date'],8,2).'</b>'.($a['oldstyle']==='1'?'<small>'.(int)substr($day['oldStyleDate'],8,2).'</small>':'');
            if ($feasts) $html .= '<span class="oc-star" aria-hidden="true">✦</span>';
            if ($a['mode']!=='year') $html .= '<span class="oc-cell-title">'.esc_html($feasts[0]['title'] ?? $events[0]['title'] ?? '').'</span><span class="oc-food">'.esc_html($day['foodLabel'] ?? '').'</span>';
            $html .= '</a>';
        }
        return $html.'</div></div>';
    }
    static function periods($periods) {
        $html='';
        foreach ($periods as $period) {
            if (!isset($period['label'],$period['start']['year'],$period['finish']['year'])) continue;
            $format = static fn($d) => sprintf('%04d-%02d-%02d',$d['year'],$d['month'],$d['day']);
            $html.='<li>'.esc_html($period['label'].' · '.self::date_label($format($period['start'])).' — '.self::date_label($format($period['finish']))).'</li>';
        }
        return $html;
    }
    static function day($day,$a) {
        $html = '<div class="oc-day"><p class="oc-date">'.esc_html(self::date_label($day['date'])).'</p>';
        if ($a['oldstyle']==='1') $html .= '<p class="oc-muted">'.esc_html($day['oldStyleDate']).' по старому стилю</p>';
        if ($a['mode']!=='readings') {
            $foodImage=''; $foodSource=$day['foodMarkers'][0]['source']??'';
            if (is_string($foodSource) && str_starts_with($foodSource,'/assets/markers/')) $foodImage='<img src="'.esc_url('https://kalender.georg-kloster.ru'.$foodSource).'" width="44" height="44" alt="">';
            $html .= '<p class="oc-fast">'.$foodImage.esc_html($day['foodLabel'] ?? '').' <small>('.($a['profile']==='parish'?'приходской профиль':'Типикон').')</small></p><ul class="oc-events">';
            foreach ($day['events'] as $event) {
                if ($event['category']==='scripture-reading') continue;
                $mark=$event['typikonMark'] ?? null;
                $html .= '<li'.(($event['typeCode']>=0 && $event['typeCode']<=2)?' class="oc-red"':'').'>';
                if ($mark && !empty($mark['svgSource']) && str_starts_with($mark['svgSource'],'/assets/typikon/')) $html .= '<img width="20" height="20" src="'.esc_url('https://kalender.georg-kloster.ru'.$mark['svgSource']).'" alt="'.esc_attr($mark['label'] ?? 'Знак Типикона').'"> ';
                $html .= esc_html($event['title']).'</li>';
            }
            $html .= '</ul>';
        }
        $readings=array_values(array_filter($day['events'],static fn($e)=>$e['category']==='scripture-reading'));
        if ($readings) {
            $html .= '<div class="oc-readings"><h3>Библейские чтения</h3><label>Перевод <select data-oc-translation><option value="">Загрузить переводы…</option></select></label><label>Размер текста <input data-oc-font type="range" min="16" max="30" value="19"></label><p class="oc-muted">Язык текста выбирается вместе с переводом. Соответствие нумерации стихов календарному источнику пока не подтверждено.</p>';
            foreach ($readings as $event) $html .= '<details data-oc-reading="'.esc_attr(wp_json_encode($event['reading'] ?? null)).'"><summary>'.esc_html($event['title']).'</summary><div class="oc-verses" aria-live="polite"></div></details>';
            $html .= '</div>';
        } elseif ($a['mode']==='readings') $html .= '<p>В источнике нет чтений для этой даты.</p>';
        return $html.'<p class="oc-permalink">'.self::day_link($day['date'],'Ссылка на этот день').'</p></div>';
    }
    static function throttle() {
        // Bound public proxy traffic. No forwarded headers or arbitrary upstream URL accepted.
        foreach (['global'=>300, hash('sha256',($_SERVER['REMOTE_ADDR'] ?? '').wp_salt())=>40] as $id=>$max) {
            $key='oc_rate_'.md5($id.gmdate('YmdHi')); $count=(int)get_transient($key);
            if ($count >= $max) return new WP_Error('rate_limit','Слишком много запросов. Повторите через минуту.',['status'=>429]);
            set_transient($key,$count+1,70);
        }
        return true;
    }
    static function rest_render($request) {
        $rate=self::throttle(); if (is_wp_error($rate)) return $rate;
        $attrs=$request->get_query_params();
        foreach ($attrs as $value) if (!is_scalar($value)) return new WP_Error('invalid','Неверные параметры.',['status'=>400]);
        $a=self::config($attrs); if (is_wp_error($a)) return new WP_Error('invalid',$a->get_error_message(),['status'=>400]);
        $response=new WP_REST_Response(['html'=>self::render($a,true)]); $response->header('Cache-Control','no-store'); return $response;
    }
    static function rest_bible($request) {
        $rate=self::throttle(); if (is_wp_error($rate)) return $rate;
        $path=$request->get_param('path');
        if (!is_string($path) || !preg_match('~^translations(?:/[a-zA-Z0-9_-]{1,80}/books(?:/[a-zA-Z0-9_-]{1,100}/chapters/[1-9][0-9]{0,2})?)?$~D',$path)) return new WP_Error('path','Неверный путь.',['status'=>400]);
        $data=self::request('bible',$path); if (is_wp_error($data)) return $data;
        $response=new WP_REST_Response($data); $response->header('Cache-Control','no-store'); return $response;
    }
    static function settings_page() {
        if (!current_user_can('manage_options')) return;
        $o=self::options();
        echo '<div class="wrap"><h1>Православный календарь</h1><p>Календарь — Календарная мастерская. Библейские тексты — BibleDesktop. Часовой пояс сайта: '.esc_html(wp_timezone_string()).'.</p>';
        if (isset($_POST['orthocal_check'])) {
            check_admin_referer('orthocal_check');
            foreach (['calendar','bible'] as $service) {
                $value=self::request($service,$service==='calendar' ? 'day' : 'translations',$service==='calendar'?['date'=>wp_date('Y-m-d'),'lang'=>$o['lang'],'profile'=>$o['profile']]:[]);
                echo '<p><strong>'.esc_html($service).':</strong> '.esc_html(is_wp_error($value)?$value->get_error_message():'Подключение работает').'</p>';
            }
        }
        echo '<form method="post" action="options.php">'; settings_fields('orthocal');
        echo '<table class="form-table"><tr><th>API-ключ календаря</th><td><input type="password" name="orthocal_options[key]" value="" autocomplete="new-password" class="regular-text"><p>'.(self::key()?'Ключ сохранён. Пустое поле оставляет его без изменений.':'Введите ключ для месяца, года и произвольных дат.').'</p><label><input type="checkbox" name="orthocal_options[clear_key]" value="1"> Удалить сохранённый ключ</label></td></tr>';
        foreach (['lang'=>['Язык календаря',['ru'=>'Русский','cu'=>'Церковнославянский','de'=>'Немецкий','uk'=>'Украинский','pl'=>'Польский']], 'profile'=>['Профиль поста',['typikon-strict'=>'Типикон','parish'=>'Приходской']], 'theme'=>['Оформление',['book'=>'Книжное','modern'=>'Современное','inherit'=>'В стиле сайта']]] as $name=>[$label,$choices]) {
            echo '<tr><th>'.esc_html($label).'</th><td><select name="orthocal_options['.$name.']">';
            foreach ($choices as $value=>$text) echo '<option value="'.esc_attr($value).'" '.selected($o[$name],$value,false).'>'.esc_html($text).'</option>';
            echo '</select></td></tr>';
        }
        echo '<tr><th>Акцентный цвет</th><td><input type="color" name="orthocal_options[accent]" value="'.esc_attr($o['accent']).'"></td></tr><tr><th>Код перевода Библии</th><td><input name="orthocal_options[translation]" value="'.esc_attr($o['translation']).'"><p>Необязательно. Каталог переводов доступен в блоке чтений.</p></td></tr>';
        foreach (['oldstyle'=>'Дата по старому стилю','compact'=>'Компактное отображение'] as $name=>$label) echo '<tr><th>'.esc_html($label).'</th><td><input type="checkbox" name="orthocal_options['.$name.']" value="1" '.checked($o[$name],'1',false).'></td></tr>';
        echo '</table>'; submit_button(); echo '</form><form method="post">'; wp_nonce_field('orthocal_check'); submit_button('Проверить оба API','secondary','orthocal_check'); echo '</form>';
        $quota=get_option('orthocal_quota'); if ($quota) echo '<p>Остаток месячной квоты при последнем запросе: '.(int)$quota['remaining'].' ('.esc_html(wp_date('d.m.Y H:i',$quota['checked'])).').</p>';
        echo '<p>Календарные ответы хранятся до 5 минут, только если API разрешает это специальным заголовком. Сохранение настроек сбрасывает кэш. Просроченные ответы при ошибках не используются.</p><h2>Блоки и шорткоды</h2><ul>';
        foreach (self::TITLES as $mode=>$title) echo '<li>'.esc_html($title).' — <code>[orthocal_'.$mode.']</code></li>';
        echo '</ul><h2>Предварительный просмотр</h2>'.self::render(['mode'=>'today']).'</div>';
    }
}
