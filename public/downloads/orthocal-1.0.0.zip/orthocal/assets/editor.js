(() => {
  const el=wp.element.createElement;
  const titles={today:'Сегодня',upcoming:'Ближайшие праздники',month:'Календарь на месяц',year:'Календарь на год',day:'День календаря',readings:'Чтения дня'};
  for(const [mode,title] of Object.entries(titles)) wp.blocks.registerBlockType('orthocal/'+mode,{
    title:'Православный календарь: '+title,icon:'calendar-alt',category:'widgets',
    edit({attributes,setAttributes}) {
      const control=(label,name,options)=>el(wp.components.SelectControl,{label,value:attributes[name]||'',options:[{label:'Настройка сайта',value:''},...options.map(([value,label])=>({value,label}))],onChange:value=>setAttributes({[name]:value})});
      const attrs=Object.fromEntries(Object.entries(attributes).filter(([,value])=>value!==''));
      return el('div',wp.blockEditor.useBlockProps(),
        el(wp.blockEditor.InspectorControls,null,el(wp.components.PanelBody,{title:'Календарь'},
          el(wp.components.TextControl,{label:'Дата (ГГГГ-ММ-ДД), пусто — сегодня',value:attributes.date||'',onChange:date=>setAttributes({date})}),
          ...(['month','year'].includes(mode)?[el(wp.components.TextControl,{label:'Год',type:'number',value:attributes.year||'',onChange:year=>setAttributes({year})})]:[]),
          ...(mode==='month'?[el(wp.components.TextControl,{label:'Месяц (1–12)',type:'number',value:attributes.month||'',onChange:month=>setAttributes({month})})]:[]),
          ...(mode==='upcoming'?[el(wp.components.RangeControl,{label:'Количество',min:1,max:10,value:Number(attributes.limit||5),onChange:limit=>setAttributes({limit:String(limit)})}),control('События','filter',[['main','Главные'],['twelve','Пасха и двунадесятые'],['great','Великие'],['memorial','Поминальные'],['all','Все']])]:[]),
          control('Язык календаря','lang',[['ru','Русский'],['cu','Церковнославянский'],['de','Немецкий'],['uk','Украинский'],['pl','Польский']]),
          control('Профиль поста','profile',[['typikon-strict','Типикон'],['parish','Приходской']]),
          control('Оформление','theme',[['book','Книжное'],['modern','Современное'],['inherit','В стиле сайта']]),
          control('Размер','compact',[['1','Компактный'],['0','Подробный']]),control('Старый стиль','oldstyle',[['1','Показывать'],['0','Скрыть']])
        )),el(wp.serverSideRender,{block:'orthocal/'+mode,attributes:attrs}));
    },save:()=>null
  });
})();
