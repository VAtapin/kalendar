<?php
if (!defined('ABSPATH')) exit;

final class Orthocal_Admin {
    static function boot($file) {
        add_action('admin_post_orthocal_cache',function(){
            if(!current_user_can('manage_options'))wp_die('Недостаточно прав.'); check_admin_referer('orthocal_cache');
            $action=sanitize_key($_POST['operation']??'');$message='';
            if($action==='data'){update_option('orthocal_cache_generation',wp_generate_uuid4(),false);$message='Кэш календарных данных сброшен.';}
            elseif($action==='check'){Orthocal_Media_Cache::recheck();$message='Проверка локальных файлов поставлена в очередь.';}
            elseif($action==='media'){$message=Orthocal_Media_Cache::clear()?'Локальные копии очищены.':'Идёт обновление файлов. Повторите позже.';}
            set_transient('orthocal_admin_notice_'.get_current_user_id(),$message,60);
            wp_safe_redirect(admin_url('admin.php?page=orthocal&tab=connection'));exit;
        });
    }
    static function packs() { return ['ornamental'=>'Орнаментальные с надписью','dark'=>'Фотографические тёмные','bronze-medallions'=>'Бронзовые медальоны','jeweled-medallions'=>'Самоцветные медальоны','photographic-vignettes'=>'Фотографические виньетки','gold-oval-medallions'=>'Золотые овальные медальоны','minimal-dark'=>'Минималистичные пиктограммы','vintage-watercolor'=>'Винтажная акварель','light-watercolor'=>'Светлая акварель','sticker-outline'=>'Контурные наклейки','soft-illustration'=>'Мягкая иллюстрация','clean-illustration'=>'Чистая иллюстрация','blue-photo'=>'Фотореалистика — синяя','rustic-photo'=>'Фотореалистика — деревенская','copper-photo'=>'Фотореалистика — медная','gold-photo'=>'Фотореалистика — золотая']; }
    static function setting($name,$label,$type='text',$choices=[],$help='') {
        $o=Orthocal_Plugin::options();$id='oc-setting-'.$name;$value=$o[$name]??'';
        echo '<label class="oc-admin-field" for="'.esc_attr($id).'">'.esc_html($label);
        if($type==='select'){echo '<select id="'.esc_attr($id).'" name="orthocal_options['.esc_attr($name).']">';foreach($choices as $key=>$text)echo '<option value="'.esc_attr($key).'" '.selected($value,(string)$key,false).'>'.esc_html($text).'</option>';echo '</select>';}
        elseif($type==='checkbox')echo '<input id="'.esc_attr($id).'" type="checkbox" name="orthocal_options['.esc_attr($name).']" value="1" '.checked($value,'1',false).'>';
        else echo '<input id="'.esc_attr($id).'" type="'.esc_attr($type).'" name="orthocal_options['.esc_attr($name).']" value="'.esc_attr($type==='password'?'':$value).'"'.($type==='password'?' autocomplete="new-password"':'').'>';
        if($help)echo '<span class="description">'.esc_html($help).'</span>';echo '</label>';
    }
    static function build_select($name,$label,$choices,$value='') {
        echo '<label class="oc-build-field" data-oc-build-wrap="'.esc_attr($name).'">'.esc_html($label).'<select data-oc-build="'.esc_attr($name).'">';
        foreach($choices as $key=>$text)echo '<option value="'.esc_attr($key).'" '.selected((string)$value,(string)$key,false).'>'.esc_html($text).'</option>'; echo '</select></label>';
    }
    static function page() {
        if(!current_user_can('manage_options'))return;
        $o=Orthocal_Plugin::options();$stats=Orthocal_Media_Cache::stats();$tabs=['connection'=>'Подключение','shortcodes'=>'Конструктор','help'=>'Помощь'];
        $tab=sanitize_key($_GET['tab']??'connection');if(!isset($tabs[$tab]))$tab='connection';
        echo '<div class="wrap oc-admin" data-oc-admin data-active-tab="'.esc_attr($tab).'" data-endpoint="'.esc_url(rest_url('orthocal/v1/')).'">';
        echo '<header class="oc-admin-hero"><div><span>КАЛЕНДАРНАЯ МАСТЕРСКАЯ · '.esc_html(Orthocal_Plugin::VERSION).'</span><h1>Православный календарь</h1><p>Подключите API календаря и BibleDesktop, затем соберите нужный блок.</p><p><a href="https://kalender.georg-kloster.ru/" target="_blank" rel="noopener noreferrer">Открыть Календарную мастерскую</a> · <a href="https://kalender.georg-kloster.ru/wordpress-plugin.html" target="_blank" rel="noopener noreferrer">Расширенная документация плагина</a></p></div><div class="oc-admin-badge">'.($o['key']||defined('ORTHOCAL_API_KEY')?'Ключ задан':'Нужен API-ключ').'<small>'.$stats['count'].' локальных файлов · '.esc_html(size_format($stats['bytes'])).'</small></div></header>';
        if($notice=get_transient('orthocal_admin_notice_'.get_current_user_id())){echo '<div class="notice notice-success"><p>'.esc_html($notice).'</p></div>';delete_transient('orthocal_admin_notice_'.get_current_user_id());}
        echo '<nav class="nav-tab-wrapper" aria-label="Православный календарь">';foreach($tabs as $key=>$label)echo '<a class="nav-tab'.($key===$tab?' nav-tab-active':'').'" href="'.esc_url(admin_url('admin.php?page=orthocal&tab='.$key)).'" data-oc-tab="'.esc_attr($key).'">'.esc_html($label).'</a>';echo '</nav>';
        echo '<form action="options.php" method="post" id="oc-settings-form" data-oc-panel="connection">';settings_fields('orthocal');
        echo '<section class="oc-admin-card"><h2>Подключение к данным</h2><p>Календарные события и праздники приходят из <a href="https://kalender.georg-kloster.ru/" target="_blank" rel="noopener noreferrer">Календарной мастерской</a> через API. Полные библейские тексты — из BibleDesktop.</p><div class="oc-admin-fields">';
        self::setting('key','API-ключ календаря','password',[],Orthocal_Plugin::key()?'Ключ сохранён. Пустое поле не меняет его.':'Без ключа доступен только сегодняшний день.');
        echo '<label class="oc-admin-check"><input type="checkbox" name="orthocal_options[clear_key]" value="1"> Удалить сохранённый ключ</label>';
        self::setting('lang','Язык календаря по умолчанию','select',['ru'=>'Русский','cu'=>'Церковнославянский','de'=>'Немецкий','uk'=>'Украинский','pl'=>'Польский']);
        self::setting('translation','Перевод Библии по умолчанию','text',[],'Код можно выбрать ниже. В конструкторе его можно переопределить для отдельного блока.');
        echo '<div class="oc-admin-field"><strong>Каталог BibleDesktop</strong><button type="button" class="button" data-oc-load-translations>Загрузить переводы</button><select data-oc-admin-translations aria-label="Доступные переводы" hidden></select><p data-oc-admin-status role="status"></p></div></div><p>Часовой пояс сайта: <strong>'.esc_html(wp_timezone_string()).'</strong>. Он меняется в общих настройках WordPress.</p><p><a href="'.esc_url(admin_url('options-general.php')).'">Открыть общие настройки</a></p><hr><h2>Локальные файлы и кэш</h2><p><strong>'.$stats['count'].'</strong> файлов · <strong>'.esc_html(size_format($stats['bytes'])).'</strong> из 64 МБ. Картинки и шрифт плагин хранит локально.</p><div class="oc-admin-fields">';
        self::setting('media_hours','Проверять картинки и шрифт','select',['6'=>'Раз в 6 часов','12'=>'Раз в 12 часов','24'=>'Раз в сутки','168'=>'Раз в неделю']);self::setting('bible_hours','Хранить библейские ответы','select',['0'=>'Не хранить','1'=>'1 час','6'=>'6 часов','24'=>'1 сутки']);echo '</div>';submit_button('Сохранить подключение');echo '</section></form>';
        echo '<section data-oc-panel="connection" class="oc-admin-card"><h2>Обслуживание</h2><form action="'.esc_url(admin_url('admin-post.php')).'" method="post"><input type="hidden" name="action" value="orthocal_cache">';wp_nonce_field('orthocal_cache');foreach(['check'=>'Проверить обновления картинок','data'=>'Сбросить кэш данных','media'=>'Очистить локальные картинки'] as $operation=>$label)echo '<button class="button" name="operation" value="'.esc_attr($operation).'">'.esc_html($label).'</button> ';echo '</form></section>';
        self::generator();self::help();echo '</div>';
    }
    static function generator() {
        $page=wp_dropdown_pages(['name'=>'oc-build-day-page','id'=>'oc-build-day-page','show_option_none'=>'Текущая страница','option_none_value'=>'0','echo'=>0]);$page=str_replace('<select ','<select data-oc-build="day_page" ',$page);
        echo '<section data-oc-panel="shortcodes" class="oc-admin-card oc-generator"><div class="oc-generator-intro"><h2>Конструктор шорткодов</h2><p>Все параметры относятся только к создаваемому блоку. Меняйте их слева — справа сразу увидите результат. Для боковой колонки выберите «Компактный».</p></div><div class="oc-generator-layout"><div class="oc-generator-controls">';
        self::build_select('mode','Что разместить',Orthocal_Plugin::TITLES,'today');self::build_select('office','Час Часослова',['horologion'=>'Весь Часослов','first-hour'=>'Первый час','third-hour'=>'Третий час','sixth-hour'=>'Шестой час','ninth-hour'=>'Девятый час','matins'=>'Утреня','vespers'=>'Вечерня'],'horologion');
        echo '<label class="oc-build-field" data-oc-build-wrap="date">Дата<input data-oc-build="date" type="date"></label><label class="oc-build-field" data-oc-build-wrap="year">Год<input data-oc-build="year" type="number" min="1900" max="2200"></label><label class="oc-build-field" data-oc-build-wrap="month">Месяц<input data-oc-build="month" type="number" min="1" max="12"></label><label class="oc-build-field" data-oc-build-wrap="limit">Количество<input data-oc-build="limit" type="number" min="1" max="10" value="5"></label>';
        self::build_select('theme','Тема',['book'=>'Книжная — тёплая','modern'=>'Современная — светлая','inherit'=>'Шрифты сайта'],'book');
        self::build_select('css_mode','CSS карточки',['plugin'=>'Оформление плагина','site'=>'Полностью CSS сайта WordPress'],'plugin');
        echo '<label class="oc-build-field" data-oc-build-wrap="accent">Акцентный цвет<input data-oc-build="accent" type="color" value="#9a352d"></label><label class="oc-build-field" data-oc-build-wrap="branding">Подпись над блоком<input data-oc-build="branding" type="text" value="Календарная мастерская"></label>';
        self::build_select('compact','Размер блока',['0'=>'Подробный','1'=>'Компактный — для боковой колонки'],'0');self::build_select('open','Открытие дня',['inline'=>'Под блоком','modal'=>'Во всплывающем окне','new'=>'В новом окне','page'=>'На отдельной странице'],'inline');self::build_select('reading_open','Библейский текст',['inline'=>'Раскрывать под ссылкой','modal'=>'Открывать во всплывающем окне'],'inline');
        self::build_select('image_size','Размер картинок поста',['small'=>'Маленький','medium'=>'Средний','large'=>'Большой'],'medium');
        echo '<label class="oc-build-field" data-oc-build-wrap="day_page">Страница подробностей дня'.$page.'</label>';
        self::build_select('lang','Язык календаря',['ru'=>'Русский','cu'=>'Церковнославянский','de'=>'Немецкий','uk'=>'Украинский','pl'=>'Польский'],'ru');self::build_select('profile','Профиль поста',['typikon-strict'=>'Типикон','parish'=>'Приходской'],'typikon-strict');self::build_select('filter','Какие события',['main'=>'Главные','twelve'=>'Пасха и двунадесятые','great'=>'Великие','memorial'=>'Поминальные','all'=>'Все'],'main');self::build_select('image_pack','Набор картинок поста',self::packs(),'dark');
        echo '<fieldset class="oc-build-field" data-oc-build-wrap="sections"><legend>Содержание карточки дня</legend>';foreach(['fasting'=>'Пост и трапеза','saints'=>'Праздники и памяти','readings'=>'Библейские чтения','texts'=>'Богослужебные тексты','icons'=>'Иконы'] as $key=>$label)echo '<label><input data-oc-build-section="'.esc_attr($key).'" type="checkbox" '.checked($key!=='icons',true,false).'> '.esc_html($label).'</label>';echo '</fieldset><fieldset class="oc-build-field" data-oc-build-wrap="event_levels"><legend>Уровни памятей</legend>';foreach(['0'=>'Двунадесятые','1'=>'Великие','2'=>'Средние','3'=>'Малые','4'=>'Остальные'] as $key=>$label)echo '<label><input data-oc-event-level="'.esc_attr($key).'" type="checkbox" checked> '.esc_html($label).'</label>';echo '</fieldset><label class="oc-build-field" data-oc-build-wrap="images"><input data-oc-build="images" type="checkbox" checked> Показывать картинки поста и знаки Типикона</label><label class="oc-build-field" data-oc-build-wrap="show_font_size"><input data-oc-build="show_font_size" type="checkbox" checked> Показывать размер текста чтений</label><label class="oc-build-field" data-oc-build-wrap="icon_limit">Количество иконок<select data-oc-build="icon_limit"><option value="all">Все иконы</option><option value="1">1</option><option value="3">3</option><option value="5">5</option><option value="8">8</option></select></label><label class="oc-build-field" data-oc-build-wrap="heading"><input data-oc-build="heading" type="checkbox" checked> Показывать общий заголовок блока</label><label class="oc-build-field" data-oc-build-wrap="show_section_titles"><input data-oc-build="show_section_titles" type="checkbox" checked> Показывать заголовки секций</label><label class="oc-build-field" data-oc-build-wrap="oldstyle"><input data-oc-build="oldstyle" type="checkbox" checked> Показывать старый стиль</label><label class="oc-build-field" data-oc-build-wrap="show_nav"><input data-oc-build="show_nav" type="checkbox" checked> Показывать «вчера/завтра»</label><label class="oc-build-field" data-oc-build-wrap="show_picker"><input data-oc-build="show_picker" type="checkbox" checked> Показывать календарь выбора даты</label><label class="oc-build-field" data-oc-build-wrap="show_copy"><input data-oc-build="show_copy" type="checkbox" checked> Показывать копирование ссылки</label><label class="oc-build-field" data-oc-build-wrap="show_search"><input data-oc-build="show_search" type="checkbox"> Показывать поиск по памятям</label>';
        echo '<label class="oc-build-field" data-oc-build-wrap="translation">Перевод Библии<input data-oc-build="translation" type="text" placeholder="Код, например synodal"></label><label class="oc-build-field" data-oc-build-wrap="scope">Раздел справочника<select data-oc-build="scope"><option value="">Все</option><option value="resurrection">Воскресные</option><option value="weekday">Дни седмицы</option><option value="common">Общие</option></select></label><label class="oc-build-field" data-oc-build-wrap="tone">Глас<input data-oc-build="tone" type="number" min="1" max="8"></label><label class="oc-build-field" data-oc-build-wrap="weekday">День седмицы<input data-oc-build="weekday" type="number" min="0" max="6"></label><label class="oc-build-field" data-oc-build-wrap="text_id">ID текста<input data-oc-build="text_id" type="text"></label>';
        echo '</div><aside class="oc-generator-preview"><h3>Предпросмотр</h3><p data-oc-generator-status role="status">Настройте блок — результат появится здесь.</p><div data-oc-preview-slot aria-live="polite"></div><label for="oc-generated-code">Готовый шорткод</label><textarea id="oc-generated-code" rows="4" readonly></textarea><button type="button" class="button button-primary" data-oc-copy-code>Скопировать шорткод</button><button type="button" class="button" data-oc-preview>Обновить сейчас</button></aside></div></section>';
    }
    static function help() {
        echo '<section data-oc-panel="help" class="oc-admin-card"><h2>Помощь</h2><p>Подключение хранит доступ к источникам и локальный кэш. Внешний вид, размер, картинки, содержание дня и поведение относятся к конкретному блоку и задаются в конструкторе.</p><h3>Как работать</h3><ol><li>Введите ключ календаря во вкладке «Подключение».</li><li>Откройте «Конструктор», выберите вид блока и настройте его слева.</li><li>Проверьте живой результат справа и скопируйте строку в блок WordPress «Шорткод».</li></ol><h3>Стандартные шорткоды</h3><p>Их можно вставить напрямую в блок «Шорткод», без конструктора:</p><pre class="oc-shortcode-list">[orthocal_today] — карточка сегодняшнего дня
[orthocal_upcoming limit="5" filter="main"] — ближайшие праздники
[orthocal_month year="2027" month="5"] — календарь на месяц
[orthocal_year year="2027"] — календарь на год
[orthocal_day date="2027-05-02"] — карточка выбранной даты
[orthocal_readings date="2027-05-02"] — библейские чтения дня
[orthocal_calendar] — общий календарь
[orthocal_fasting] — пост и трапеза
[orthocal_saints] — памяти святых
[orthocal_feasts limit="5"] — список праздников
[orthocal_memorial] — поминальные дни
[orthocal_pascha year="2027"] — дата Пасхи и сведения о ней
[orthocal_fasts year="2027"] — посты года
[orthocal_date] — дата по новому и старому стилю
[orthocal_texts] — библиотека богослужебных текстов
[orthocal_troparia] — тропари
[orthocal_kontakia] — кондаки
[orthocal_prayers] — молитвы
[orthocal_magnifications] — величания
[orthocal_horologion] — полный справочник Часослова</pre><details><summary>Почему компактный блок выглядит иначе?</summary><p>Он предназначен для боковой колонки: уменьшает ячейки и скрывает длинные подписи сетки.</p></details><details><summary>Почему не загружается перевод Библии?</summary><p>Каталог приходит из BibleDesktop. Плагин покажет точную ошибку подключения; календарные данные от этого не останавливаются.</p></details><details><summary>Что означают иконы?</summary><p>Показываются все иконы, которые календарный API передаёт для выбранной даты.</p></details></section>';
    }
}
