=== Georg-Kloster Calendar Workshop ===
Contributors: atapin
Tags: calendar, orthodox, bible
Requires at least: 6.3
Tested up to: 7.1
Requires PHP: 8.0
Stable tag: 1.3.79
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Orthodox calendar for WordPress: feasts, fasting, commemorations, readings, liturgical texts and Gutenberg blocks.

== Description ==

Adds 22 dynamic Gutenberg blocks and shortcodes. Calendar and Bible data come from the external services listed below; no calendar database is included in the plugin.

== Source code and development ==
Public source repository: https://github.com/VAtapin/wp_orthodox_calendar
JavaScript and CSS sources: https://github.com/VAtapin/wp_orthodox_calendar/tree/main/assets

The files assets/admin.js, assets/calendar.js, assets/editor.js, assets/admin.css and assets/calendar.css are the original, human-readable sources and are included in this ZIP. They are served directly by WordPress. There is no transpilation, bundling, minification or generated JavaScript/CSS, and no separate hidden source tree. The scripts use WordPress-provided Gutenberg libraries rather than bundled copies.

Edit these source files directly. No npm build is required for plugin installation or development. To check JavaScript syntax, run node --check assets/admin.js, node --check assets/calendar.js and node --check assets/editor.js. PHP files can be checked with php -l. Optional formatting: npx prettier@3.6.2 --write assets/*.js assets/*.css. The repository includes scripts/build-language-files.mjs for rebuilding MO catalogues with Node.js. The release packaging procedure is documented in the public repository README.md.

== Installation ==
1. WordPress → Plugins → Add New → Upload Plugin: orthocal-1.3.79.zip.
2. Activate the plugin.
3. The calendar works immediately. Open Georg-Kloster Calendar Workshop → Connection to change the Bible Desktop API address.
4. Add blocks from the Widgets category or shortcodes to a page.

The retired Kalendar key is not sent to Bible Desktop. Saved legacy settings are retained but do not authorize public calendar requests.
The calendar, texts, translations, and icons API is configured in Georg-Kloster Calendar Workshop → Connection. Its current default address is https://bible-desktop.com and no file access is required.

== Shortcodes ==
<code>[orthocal_today]</code>
<code>[orthocal_upcoming limit="5" filter="main"]</code>
<code>[orthocal_month year="2027" month="5"]</code>
<code>[orthocal_year year="2027"]</code>
<code>[orthocal_day date="2027-05-02"]</code>
<code>[orthocal_readings date="2027-05-02"]</code>
<code>[orthocal_calendar open="modal"]</code>
<code>[orthocal_fasting]</code>
<code>[orthocal_saints]</code>
<code>[orthocal_feasts limit="5"]</code>
<code>[orthocal_memorial]</code>
<code>[orthocal_pascha year="2027"]</code>
<code>[orthocal_fasts year="2027"]</code>
<code>[orthocal_date]</code>
<code>[orthocal_texts]</code>
<code>[orthocal_troparia scope="resurrection" tone="1"]</code>
<code>[orthocal_kontakia scope="weekday" weekday="1"]</code>
<code>[orthocal_prayers]</code>
<code>[orthocal_magnifications]</code>
<code>[orthocal_horologion]</code>

<code>open="inline|modal|page"</code> controls how the day opens; <code>reading_open="inline|modal"</code> controls readings. For a separate page, place <code>[orthocal_day]</code> on it and select that page in the settings. <code>sections="fasting,saints,readings,texts,icons"</code>, <code>images="0|1"</code>, and <code>heading="0|1"</code> control the content. The admin generator previews parameters and output.
image_size="120" sets a fasting-image height in pixels; its width retains the source image ratio. Existing small, medium, and large shortcodes continue to use heights of 28, 44, and 72 px.
The reference library contains an initial corpus of 98 Church Slavonic texts with sources and awaits liturgical editorial review. It does not automatically assign a text to a daily service. Akathists are planned in BibleDesktop and are not yet connected.

General parameters: <code>lang="ru|cu|de|uk|pl"</code>, <code>profile="typikon-strict|parish"</code>, <code>theme="book|modern|inherit"</code>, <code>compact="0|1"</code>, and <code>oldstyle="0|1"</code>. The Horologion uses a protected service route and includes Sixth Hour inserts. An empty date means the current date in the WordPress timezone. Supported years are 1900–2200.
Upcoming-event filters: main (major and memorial), twelve (Pascha and the Twelve Great Feasts), great, memorial, and all. The search covers the supplied date and the next 366 days, with a maximum of 10 events.

== External Services ==
Calendar API: https://bible-desktop.com/api/v1/calendar/
Used to calculate dates, feasts, fasting, commemorations and reading references. Loading a block, its admin preview or changing the date sends the date/period, language, calendar profile and display/filter parameters from the WordPress server. Public requests include X-Calendar-Client: orthocal-wordpress. Normal public use needs no registration or key.
Terms of Service: https://bible-desktop.com/pages/api-terms
Privacy Policy: https://bible-desktop.com/pages/api-privacy

Bible Desktop API: https://bible-desktop.com/api/
Used for Bible translations, books, chapters, liturgical libraries, hagiographies and icon catalogues/images. Opening readings or a library sends the selected translation, book/chapter, language, work identifier or pagination/filter parameters. Loading icons sends the calendar month/day or material/image identifier. On cache misses, WordPress downloads images and fonts; scheduled cache revalidation sends conditional HTTP headers. Bible Desktop calculates the calendar locally. The retired Kalendar key is never sent to the replacement provider.
Terms of Service: https://bible-desktop.com/pages/api-terms
Privacy Policy: https://bible-desktop.com/pages/api-privacy

Both services receive the requesting server IP address, request time, requested resource and technical HTTP headers. The plugin does not send visitor IP addresses, names, email addresses, WordPress passwords or post contents. Remote media are cached and served locally. Requests may be skipped while a valid cache entry is available. Full texts, icons and hagiographies are not bundled in the ZIP; their respective rights remain applicable.
The single Bible Desktop API origin can be changed in the Connection settings. These links describe the default providers; administrators choosing a different provider must review and disclose that provider's terms and privacy policy to their users.

== Cache and access ==
The updated calendar API is required: upcoming, view=summary, and the X-Calendar-Application-Cache-TTL header.
Successful calendar responses are retained for up to 300 seconds only when allowed by the API; access revocation and database changes appear no later than this expiry. Stale data is not used after errors. Responses without the allowing header are not retained between requests.
Bible responses are retained for the selected 0/1/6/24 hours (24 by default); no-store disables retention unless separately permitted by the API. The browser deduplicates simultaneous requests.
Local images and fonts are stored in uploads/orthocal-cache. Remote photos are resized to a maximum edge of 1200 pixels and compressed to no more than 100 KB before they are saved. Conditional ETag/Last-Modified checks through WP-Cron run every 6/12/24/168 hours (24 by default). A changed file receives a new hashed URL, while the last working copy remains available after a failure. The limit is 200 MB; old versions can be cleared in the admin area. Media Library files are not affected.
Public REST routes are limited to fixed sources and an allowlist of parameters. WordPress counters limit ordinary traffic; configure web-server rate limiting as well for strict protection against distributed quota exhaustion.
If the site has full-page caching, exclude calendar pages or use a TTL of no more than 300 seconds and clear it at midnight in the site timezone. Otherwise, HTML can outlive the API data.
Saving settings invalidates the plugin cache. Deactivation preserves settings.

== Features ==
22 dynamic Gutenberg blocks and shortcodes, a dedicated plugin menu, a live-preview generator with shortcode copying, built-in help, server-rendered HTML, date switching without reloads, modal dialogs, daily-commemoration search, ?orthocal_date=YYYY-MM-DD permalinks, independent blocks, three themes, responsive layouts, print styles, and keyboard navigation.
Settings, Gutenberg blocks, day cards and the reader support Russian, German, Ukrainian and Polish labels; the calendar-data language and Bible language are chosen separately. Calendar translations can be incomplete. Built-in liturgical texts are Church Slavonic, with German editions available through links. Icon images and hagiographies are never substituted for missing data.

== Screenshots ==

1. Day card with actual icons, commemorations, fasting rules and Bible readings.
2. Monthly calendar with feast days, fasting rules and dates in the old style.
3. Yearly calendar with Pascha and the twelve monthly grids.
4. Shortcode generator with block settings and a live preview.
5. Full liturgical text reader with language selection and source attribution.
6. Church Slavonic text displayed using the Monomakh font.
7. Mobile day card with responsive navigation and actual icons.

== Changelog ==

= 1.3.79 =
* Show the API-recommended vestment colour as a patterned ornament in day, month and year views.
* Place the day’s source commemoration above the horizontal vestment ornament without repeating the colour name.

= 1.3.78 =
* Use US English source strings for PHP, JavaScript and Gutenberg blocks.
* Preserve Russian, German, Ukrainian and Polish translations under the new English keys.
* Distinguish month-name and date contexts and retain independent block and text languages.

= 1.3.77 =
* Connect settings, Gutenberg and reader labels to WordPress gettext and script translations.
* Preserve existing translations and add complete Russian, German, Ukrainian and Polish catalogues.
* Keep each block language and liturgical text language independent of the site locale.

= 1.3.76 =
* Show the actual historical edition year and credit of stored German prayers.
* Support the reviewed German morning, evening and Communion rules through existing APIs.

= 1.3.75 =
* Display lection numbers only for unambiguous exact source-coordinate matches.
* Preserve source variants and ambiguous candidates without guessing a number.

= 1.3.74 =
* Resolve saved legacy prayer links to complete canonical works.
* Add prayer groups and keep actual text languages explicit.
* Invalidate old prayer copies and cache full editions by content revision.

= 1.3.73 =
* Unslash, sanitize and validate public date and client IP inputs.
* Explain read-only navigation and necessary page-cache/database integrations to Plugin Check.

= 1.3.72 =
* Include readable JavaScript/CSS sources and document their public repository and development workflow.
* Validate complete fasting-period dates before rendering malformed external API data.
* Use the established orthocal prefix for all response, cooldown and rate-limit transients.


= 1.3.71 =
All calendar requests now use the configured Bible Desktop provider. Removed the separate Kalendar API origin and key forwarding. Decorative packs, Typikon signs and Monomakh are bundled locally; shortcodes and galleries are preserved.

= 1.3.70 =
* Rename the plugin to Georg-Kloster Calendar Workshop and use the matching text domain.
* Document external API requests and link to provider terms and privacy policies.
* Preserve existing blocks, shortcodes and settings.

= 1.3.69 =
* Compress remote icon photos to no more than 100 KB before saving them in WordPress.
* Clear full-size files from older plugin versions once after updating.

= 1.3.68 =
* Restored https://bible-desktop.com as the current default public API address.

= 1.3.67 =
* Fixed icon loading when the configured public API returns image files from a separate media domain.

= 1.3.66 =
* Added an editable public API address in the plugin settings.

= 1.3.65 =
* Centralized the calendar API origin.

= 1.3.64 =
* Increased the persistent local media cache limit from 64 MB to 200 MB.
* Renamed the plugin to Orthodox Calendar – Workshop and aligned the text domain with its WordPress.org slug.
* Updated the tested WordPress version to 7.1.

= 1.3.63 =
* Align the WordPress localization text domain with the approved plugin slug and add the tested WordPress version.

= 1.3.62 =
* Corrected the Plugin URI for WordPress.org submission; it now differs from the author URL.

= 1.3.61 =
* The configured number of icons limits only cards in the block; every daily icon and every image remains available in its gallery.
* Prevented theme lightboxes from replacing the plugin's icon gallery.
* Added Russian and German plugin-header translations.
